

<?php $__env->startSection('content'); ?>
<div class="parte-principal">
<!-- <img id="inicio-img" src="<?php echo e(asset('img/inicio.jpg')); ?>" alt=""> -->
hola mundo
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\primerlaravel-app\resources\views/index.blade.php ENDPATH**/ ?>