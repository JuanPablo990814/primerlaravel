

<?php $__env->startSection('content'); ?>

<h2 id="txtalojamiento">Tours</h2>
<br>
        <div class="row">
            <div class="col">
                <ul class="planes">
                <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <div class="foto">
                            <a>
                                <img src="<?php echo e($c -> foto); ?>" alt="<?php echo e($c -> ubicacion); ?>" title="<?php echo e($c -> ubicacion); ?>"/>
                            </a>
                            <span><?php echo e($c -> costo_persona); ?> por persona</span>
                        </div>
                        <div class="descripcion">
                            <h5><?php echo e($c -> ubicacion); ?></h5>
                            <a>
                                <h2><?php echo e($c -> alojamiento); ?></h2>
                            </a>
                            <p><?php echo e($c -> descripcion); ?></p>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\primerlaravel-app\resources\views/usandodb.blade.php ENDPATH**/ ?>