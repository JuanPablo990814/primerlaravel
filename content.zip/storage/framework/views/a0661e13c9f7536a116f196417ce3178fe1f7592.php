

<?php $__env->startSection('content'); ?>
<!-- <img id="inicio-img" src="<?php echo e(asset('img/inicio.jpg')); ?>" alt=""> -->

<h2 id="txtalojamiento">Alojamientos</h2>
<br>
        <div class="row">
            <div class="col">
                <ul class="planes">
                    <li>
                        <div class="foto">
                            <a>
                                <img src="https://loremflickr.com/320/240/travel" alt="La Pintada" title="La Pintada"/>
                            </a>
                            <span>30000 por persona</span>
                        </div>
                        <div class="descripcion">
                            <h5>La Pintada</h5>
                            <a>
                                <h2>Finca Hotel Campestre</h2>
                            </a>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus et eros at augue aliquam dignissim ut non purus. Curabitur finibus molestie turpis eget fringilla. Pellentesque malesuada consectetur fringilla. Suspendisse vitae sem in nunc elementum suscipit.</p>
                        </div>
                    </li>
                    <li>
                        <div class="foto">
                            <a>
                                <img src="https://loremflickr.com/320/240/travel" alt="La Pintada" title="La Pintada"/>
                            </a>
                            <span>30000 por persona</span>
                        </div>
                        <div class="descripcion">
                            <h5>La Pintada</h5>
                            <a>
                                <h2>Finca Hotel Campestre</h2>
                            </a>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus et eros at augue aliquam dignissim ut non purus. Curabitur finibus molestie turpis eget fringilla. Pellentesque malesuada consectetur fringilla. Suspendisse vitae sem in nunc elementum suscipit.</p>
                        </div>
                    </li>
                    <li>
                        <div class="foto">
                            <a>
                                <img src="https://loremflickr.com/320/240/travel" alt="La Pintada" title="La Pintada"/>
                            </a>
                            <span>30000 por persona</span>
                        </div>
                        <div class="descripcion">
                            <h5>La Pintada</h5>
                            <a>
                                <h2>Finca Hotel Campestre</h2>
                            </a>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus et eros at augue aliquam dignissim ut non purus. Curabitur finibus molestie turpis eget fringilla. Pellentesque malesuada consectetur fringilla. Suspendisse vitae sem in nunc elementum suscipit.</p>
                        </div>
                    </li>
                    <li>
                        <div class="foto">
                            <a>
                                <img src="https://loremflickr.com/320/240/travel" alt="La Pintada" title="La Pintada"/>
                            </a>
                            <span>30000 por persona</span>
                        </div>
                        <div class="descripcion">
                            <h5>La Pintada</h5>
                            <a>
                                <h2>Finca Hotel Campestre</h2>
                            </a>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus et eros at augue aliquam dignissim ut non purus. Curabitur finibus molestie turpis eget fringilla. Pellentesque malesuada consectetur fringilla. Suspendisse vitae sem in nunc elementum suscipit.</p>
                        </div>
                    </li>
                    <li>
                        <div class="foto">
                            <a>
                                <img src="https://loremflickr.com/320/240/travel" alt="La Pintada" title="La Pintada"/>
                            </a>
                            <span>30000 por persona</span>
                        </div>
                        <div class="descripcion">
                            <h5>La Pintada</h5>
                            <a>
                                <h2>Finca Hotel Campestre</h2>
                            </a>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus et eros at augue aliquam dignissim ut non purus. Curabitur finibus molestie turpis eget fringilla. Pellentesque malesuada consectetur fringilla. Suspendisse vitae sem in nunc elementum suscipit.</p>
                        </div>
                    </li>
                    <li>
                        <div class="foto">
                            <a>
                                <img src="https://loremflickr.com/320/240/travel" alt="La Pintada" title="La Pintada"/>
                            </a>
                            <span>30000 por persona</span>
                        </div>
                        <div class="descripcion">
                            <h5>La Pintada</h5>
                            <a>
                                <h2>Finca Hotel Campestre</h2>
                            </a>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus et eros at augue aliquam dignissim ut non purus. Curabitur finibus molestie turpis eget fringilla. Pellentesque malesuada consectetur fringilla. Suspendisse vitae sem in nunc elementum suscipit.</p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\primerlaravel-app\resources\views/repitiendocode.blade.php ENDPATH**/ ?>