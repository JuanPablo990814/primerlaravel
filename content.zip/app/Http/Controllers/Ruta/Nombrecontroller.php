<?php

namespace App\Http\Controllers\Ruta;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Nombrecontroller extends Controller
{
    public function hola(){
        return "Hola desde controlador";
    }
}

