@extends('plantilla')

@section('content')
<div class="parte-principal">
<!-- <img id="inicio-img" src="{{ asset('img/inicio.jpg') }}" alt=""> -->
hola mundo contacto
</div>
@endsection
