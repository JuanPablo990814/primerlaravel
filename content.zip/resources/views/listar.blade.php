@extends("plantilla")

@section('content')

HOLAMUNDO

@endsection